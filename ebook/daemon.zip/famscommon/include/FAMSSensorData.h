/* Copyright© 2018 FUJITSU LIMITED All Rights Reserved. */
/*!
 * @file        FAMSSensorData.h
 * @brief       Header file of class FAMSSensorData.
 * @author      thanglq
 * @date        2019/11/14
 */

#ifndef FAMS_SENSOR_DATA_H_
#define FAMS_SENSOR_DATA_H_

#include <vector>
#include <string>

namespace famscommon {
    /*!
     * @class FAMSSenSorData
     * @brief Store different map data request
     */
    class FAMSSensorData {
    public:
        /*!
         * @brief Constructor.
         * @param None.
         * @return None.
         */
        FAMSSensorData(void):
            mAccumulatedTime {""},
            mCisternCode {""},
            mType {},
            mValue {},
            mUnit {}
        {
        }

        /*!
         * @brief Get accumulated time
         *
         * @param None
         * @return  mAccumulatedTime
         */
        inline const std::string &getAccumulatedTime() const {
            return mAccumulatedTime;
        }

        /*!
         * @brief Set mAccumulatedTime
         *
         * @param [in] accumulatedTime accumulated time
         * @return None
         */
        inline void setAccumulatedTime(std::string &_accumulatedTime) { /*pgr2227*/
            mAccumulatedTime = _accumulatedTime;
        }

        /*!
         * @brief Get cistern code
         *
         * @param None
         * @return  mCisternCode
         */
        inline const std::string &getCisternCode() const {
            return mCisternCode;
        }

        /*!
         * @brief Set mCisternCode
         *
         * @param [in] cisternCode cistern code
         * @return None
         */
        inline void setCisternCode(const std::string &_cisternCode) { /*pgr2227*/
            mCisternCode = _cisternCode;
        }

        /*!
         * @brief Get type
         *
         * @param None
         * @return mType
         */
        inline const std::vector<int> &getType(void) const {
            return mType;
        }

        /*!
         * @brief set type
         *
         * @param [in] type
         * @return None
         */
        inline void setType(const std::vector<int> &_type) {
            mType = _type;
        }

        /*!
         * @brief Get value
         *
         * @param None
         * @return mValue
         */
        inline const std::vector<double> &getValue(void) const {
            return mValue;
        }

        /*!
         * @brief set value
         *
         * @param [in] value
         * @return None
         */
        inline void setValue(const std::vector<double> &_value) {
            mValue = _value;
        }

        /*!
         * @brief Get unit
         *
         * @param None
         * @return mUnit
         */
        inline const std::vector<std::string> &getUnit(void) const {
            return mUnit;
        }

        /*!
         * @brief set unit
         *
         * @param [in] unit
         * @return None
         */
        inline void setUnit(const std::vector<std::string> &_unit) {
            mUnit = _unit;
        }

    private:
        //! accumulated time
        std::string mAccumulatedTime;
        std::string mCisternCode;
        std::vector<int> mType;
        std::vector<double> mValue;
        std::vector<std::strig> mUnit;
    };
}
#endif /* FAMS_SENSOR_DATA_H_ */
