





List<SoftwareBitmap> faceImages = new List<SoftwareBitmap>();
IList<Windows.Media.FaceAnalysis.DetectedFace> faces = null;
IList<Windows.Media.FaceAnalysis.DetectedFace> facesDetected = new List<Windows.Media.FaceAnalysis.DetectedFace>();
private async Task Capture()
{
    VideoEncodingProperties videoProperties = _mediaCapture.VideoDeviceController.GetMediaStreamProperties(MediaStreamType.Photo) as VideoEncodingProperties;

    const BitmapPixelFormat InputPixelFormat = BitmapPixelFormat.Nv12;
    using (VideoFrame previewFrame = new VideoFrame(InputPixelFormat, (int)videoProperties.Width, (int)videoProperties.Height))
    {
        await this._mediaCapture.GetPreviewFrameAsync(previewFrame);
        // The returned VideoFrame should be in the supported NV12 format but we need to verify this.
        if (FaceDetector.IsBitmapPixelFormatSupported(previewFrame.SoftwareBitmap.BitmapPixelFormat))
        {
            SoftwareBitmap originalBitmap = null;
            originalBitmap = SoftwareBitmap.Convert(previewFrame.SoftwareBitmap, BitmapPixelFormat.Bgra8, BitmapAlphaMode.Premultiplied);

            faces = await faceTracker1.DetectFacesAsync(previewFrame.SoftwareBitmap);
            faceImages.Add(originalBitmap);
            facesDetected.Add(faces[0]);
        }
    }

}


private async Task<string> DetectionFace1(int interVal)
{
    int noFace = 0;
    int targetFace = 0;
    string targetName = null;
    string recognizeFace = null;
    
    for(int i = 0; i < interVal; i++)
    {
        await Capture();
        
        if(faces == null || faces.Count == 0)
        {
            noFace++;
        }
        else 
        {
            var result = FaceRecognition();
            if (targetName == null) {
              // 最初に認識した顔の名前を記録する
                targetName = result.Name;
                targetFace ++;
               continue;
            }
            if (result.Name == targetName && result.Score > 0.6) {
              // 同じ顔を認識し、スコア値が0.6より大きい
              targetFace ++;
            }
        }

        await Task.Delay(2000);

    }

    if (targetName == interVal) {
     // すべて同じ顔で、すべてスコア値が0.6より大きい
     recognizeFace = targetName;
    }
    else if (noFace == interVal) {
        // すべて顔検出しなかった
        recognizeFace = "None";
    }
    else {
        // 1つ以上顔を検出したが、特定の顔だと判定できなかった
        recognizeFace = "Unknown";
    }
    return recognizeFace;
}


private  bool FaceRecognition()
{
    bool ret = true;
    List<FaceData> faceDatas = new List<FaceData>();
    for (int i = 0; i < faceImages.Count; i++)
    {
        faceDatas.Add(
            new FaceData
            {
                FrameImage = SoftwareBitmap.Copy(faceImages[i]),
                FaceBB = new FaceWrapperCLI.FaceBox
                {
                    Left = (int)facesDetected[i].FaceBox.X,
                    Right = (int)(facesDetected[i].FaceBox.X + facesDetected[i].FaceBox.Width),
                    Top = (int)facesDetected[i].FaceBox.Y,
                    Bottom = (int)(facesDetected[i].FaceBox.Y + facesDetected[i].FaceBox.Height)
                }
            });
    }


    UserData userData = new UserData
    {
        UserName = "",
        FaceDatas = faceDatas,
        FrameImage = SoftwareBitmap.Copy(faceImages[0])
    };
    
    
    FaceBox[] trackings;
    // sample call
    IList<FaceInfo> faceInfos = new List<FaceInfo>();
    ErrorCode errorCode = ErrorCode.SUCCESS;
    IList<ErrorInfo> errorInfo = new List<ErrorInfo>();
    
    if (isTracking)
    {
        errorCode = _trackingHelper.Start(userData, faceInfos, errorInfo);
      
    }
    else
    {
        if (_trackingHelper.IsStop == false && _trackingHelper.IsRun == false)
        {
            _trackingHelper.Stop(errorInfo);
        }
        trackings = new FaceBox[0];
    }
    
    if (errorCode == ErrorCode.SUCCESS && isTracking)
    {
        FaceInfo[] faceInfos1 = new FaceInfo[faceInfos.Count];
        faceInfos.CopyTo(faceInfos1, 0);
        errorCode = DrawHelper.Visualize(originalBitmap, faceInfos1, errorInfo);
    }
    var ignored = this.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
    {
        _previewRenderer.RenderFrame(originalBitmap);
    });

    return ret;
}




List<SoftwareBitmap> faceImages = new List<SoftwareBitmap>();
private async Task<IList<Windows.Media.FaceAnalysis.DetectedFace>> CaptureAndFaceDetect()
{
    //Debug.WriteLine("CaptureAndFaceDetect -->begin ");
    IList<Windows.Media.FaceAnalysis.DetectedFace> faces = null;
    VideoEncodingProperties videoProperties = _mediaCapture.VideoDeviceController.GetMediaStreamProperties(MediaStreamType.Photo) as VideoEncodingProperties;
    // Create a VideoFrame object specifying the pixel format we want our capture image to be (NV12 bitmap in this case).
    // GetPreviewFrame will convert the native webcam frame into this format.
    const BitmapPixelFormat InputPixelFormat = BitmapPixelFormat.Nv12;
    using (VideoFrame previewFrame = new VideoFrame(InputPixelFormat, (int)this.videoProperties.Width, (int)this.videoProperties.Height))
    {
        await this.mediaCapture.GetPreviewFrameAsync(previewFrame);

        // The returned VideoFrame should be in the supported NV12 format but we need to verify this.
        if (FaceDetector.IsBitmapPixelFormatSupported(previewFrame.SoftwareBitmap.BitmapPixelFormat))
        {
            SoftwareBitmap originalBitmap = null;
            originalBitmap = SoftwareBitmap.Convert(previewFrame.SoftwareBitmap, BitmapPixelFormat.Bgra8, BitmapAlphaMode.Premultiplied);

            faces = await faceTracker1.DetectFacesAsync(previewFrame.SoftwareBitmap);
            faceImages.Add(originalBitmap);
        }
    }
    //Debug.WriteLine("CaptureAndFaceDetect -->end ");
    return faces;
}


private async Task<string> DetectionFace(int interVal)
{
    int noFace = 0;
    int targetFace = 0;
    string targetName = null;
    string recognizeFace = null;
    
    for(int i = 0; i < interVal; i++)
    {
        var faces = await CaptureAndFaceDetect();
        
        if(faces == null || faces.Count == 0)
        {
            noFace++;
        }
        else 
        {
            var result = FaceRecognition(faces);
            if (targetName == null) {
              // 最初に認識した顔の名前を記録する
                targetName = result.Name;
                targetFace ++;
               continue;
            }
            if (result.Name == targetName && result.Score > 0.6) {
              // 同じ顔を認識し、スコア値が0.6より大きい
              targetFace ++;
            }
        }

        await Task.Delay(2000);

    }

    if (targetName == interVal) {
     // すべて同じ顔で、すべてスコア値が0.6より大きい
     recognizeFace = targetName;
    }
    else if (noFace == interVal) {
        // すべて顔検出しなかった
        recognizeFace = "None";
    }
    else {
        // 1つ以上顔を検出したが、特定の顔だと判定できなかった
        recognizeFace = "Unknown";
    }
    return recognizeFace;
}


private  IList<FaceInfo> FaceRecognition(IList<Windows.Media.FaceAnalysis.DetectedFace> faces)
{
    FaceBox[] trackings;
    // sample call
    IList<FaceInfo> faceInfos = new List<FaceInfo>();
    ErrorCode errorCode = ErrorCode.SUCCESS;
    IList<ErrorInfo> errorInfo = new List<ErrorInfo>();

    if (isTracking && faces != null)
    {
        List<FaceData> faceDatas = new List<FaceData>();
        for (int i = 0; i < faceImages.Count; i++)
        {
            faceDatas.Add(
                new FaceData
                {
                    FrameImage = SoftwareBitmap.Copy(faceImages[i]),
                    FaceBB = new FaceWrapperCLI.FaceBox
                    {
                        Left = (int)faces[i].FaceBox.X,
                        Right = (int)(faces[i].FaceBox.X + faces[i].FaceBox.Width),
                        Top = (int)faces[i].FaceBox.Y,
                        Bottom = (int)(faces[i].FaceBox.Y + faces[i].FaceBox.Height)
                    }
                });
        }


        UserData userData = new UserData
        {
            UserName = "",
            FaceDatas = faceDatas,
            FrameImage = SoftwareBitmap.Copy(faceImages[0])
        };
        errorCode = _trackingHelper.Start(userData, faceInfos, errorInfo);
      
    }
    else
    {
        if (_trackingHelper.IsStop == false && _trackingHelper.IsRun == false)
        {
            _trackingHelper.Stop(errorInfo);
        }
        trackings = new FaceBox[0];
    }
    
    if (errorCode == ErrorCode.SUCCESS && isTracking)
    {
        FaceInfo[] faceInfos1 = new FaceInfo[faceInfos.Count];
        faceInfos.CopyTo(faceInfos1, 0);
        errorCode = DrawHelper.Visualize(originalBitmap, faceInfos1, errorInfo);
    }
    var ignored = this.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
    {
        _previewRenderer.RenderFrame(originalBitmap);
    });

    return faceInfos;
}