
Q&A: trường hợp CaptureAndFaceDetect() trả về nhiều faces

xử lý như thế nào:

lần 1 = [faceA, faceB, faceC]
lần 2 = [faceA, faceB, "unknown"]
lần 3 = [faceA, "unknown", "unknown"]
lần 4 = [faceA, "unknown", faceC]
lầm 5 = [faceA, "unknown", faceC]

thì cách tính recognize_face như thế nào?

result = [faceA, "unknown", faceC]

khách hàng trả lời như sau:

> その時、、recognize_faceの値が以下の値と同じような認識でよろしいでしょうか？
> result = [faceA, "unknown",  "unknown"]
はい、これでよいです。
例では、5回すべて3人を認識していますが、途中で2人や1人になった場合も、同じ顔が5回出てきたらその顔を結果とするということにしてください。つまり、
１回目 = [faceA, faceB, faceC]
２回目 = [faceA, faceB, "unknown"]
３回目 = [faceA, "unknown"]
４回目 = [faceA,  faceC]
５回目 = [faceA, "unknown", faceC]
という場合(2回目と3回目は2人だけ認識できた場合)も、
result = [faceA, "unknown",  "unknown"]
となるということにしておいてください。



1--> {A, 1}, {B, 1}, {C, 1}
2--> {A, 2}, {B, 2}, {C, 1}, {unknown, 1}
3->> {A, 3}, {B, 2}, {C, 1}, {unknown, 2}
4->> {A, 4}, {B, 2}, {C, 2}, {unknown, 2}
5->> {A, 5}, {B, 2}, {C, 3}, {unknown, 2}






int noface = 0;
int target_face = 0;
string target_name = null;
bool isFirstDetect = true;

for (i=0; i < 5; i++) {
    // 撮影し、顔検出(FaceDetection)
    faces = CaptureAndFaceDetect();
    if (faces == null) {
      // 顔検出しなかった
       noface ++;
    } else {
      // 顔検出したので、顔認識して結果を判定する
			
			for (face: faces) {
				result = FaceRecognition(face);
				
			
			}
			
       results = FaceRecognition(face);
      if (target_name == null) {
        // 最初に認識した顔の名前を記録する
         target_name = result.Name;
         target_face ++;
        continue;
     }
      if (result.Name == target_name && result.Score > 0.6) {
        // 同じ顔を認識し、スコア値が0.6より大きい
        target_face ++;
      }
   }
  // 次の撮影まで200ms待つ
   WaitForNextCapture(200);
}


/// lần 1: A , B, unknown
/// lần 2: A , B, C
/// lần 3: A , unknown, C
/// lần 4: A , B
/// lần 5: A , B, C, unknown

1 ->> {A, 1}, {B, 1}, {unknown, 1}

2 ->> {A, 2}, {B, 2}, {unknown, 1}, {C, 1}

3 ->> {A, 3}, {B, 2}, {unknown, 1}, {C, 2}

4 ->> {A, 4}, {B, 3}, {unknown, 1}, {C, 2}

5 ->> {A, 5}, {B, 4}, {unknown, 1}, {C, 3}

kết quả ->> A - 5, "unknown", "unknown", "unknown"


//--------------------------------------------------------------------------------------
  
	int noFace = 0;
	bool isFirstDetect = true;
	map<string name, int count> mapDetect;
	
	
	for (int i = 0; i < N; i++) {
	
		faces = CaptureAndFaceDetect();
		
		if(faces == null || faces.Count == 0) {
			noFace++;
		} else {
			
			results = FaceRecognition(faces);
			
		  if (isFirstDetect) {
				// thực hiện push kết quả vào map
				isFirstDetect = false;
				for (res : results) {
					mapDetect[res.Name] = 1; 
				}
				
				continue;
			}
			
			// thưc hiện kiểm tra xem trong map đã có Name
			// nếu có thì check score > 0.6 và count ++
			// nếu không có name trong map thì thực hiện add vào map với count = 1
			for (res : results) {
				
				if(mapDetect[res.Name] != null && res.Score > 0.6) {
					int tmp = mapDetect[res.Name].second();
					mapDetect[res.Name] = tmp + 1;
				} else {
					mapDetect[res.Name] = 1;
				}
				
			}
		
		}
		
		// 次の撮影まで200ms待つ
    WaitForNextCapture(200);
	}

// check results
	if (noFace == N) {
		recognize_face.push_back("none");
	} else {
		for(res : mapDetect) {
			int count = res.second();
			
			if (count == N) {
			  recognize_face.push_back(res.first());
			} else {
				recognize_face.push("unknown");
			}
		}
	}


/// ==================================


	for (int i = 0; i < N; i++) {
		
		
		
		
		
	}



		if (isFirstDetect) {
			isFirstDetect = false;
			status2 = DetectFace();
			
			if(status2 == "none") {
				timer = 3000; // 3 min
			} else if(status2 == "FACEID" || status2 == "unknown") {
				timer = 10; // 10 second
			}
			status1 = status2;
		}

  ///=======================================
	
	
	bool isFirstDetect = true;
	void ControlDetectFace() {

    string status1 = "no use";
		string status2 = null;
		int timer = 0;

		while(true) {
			
			WaitForNextDetectFace(timer);
			status2 = DetectFace();
			
			if (isFirstDetect) {
				isFirstDetect = false;
				if (status2 == "none") {
					timer = 3000;
				} else {
					timer = 10;
				}
				status1 = status2;
				continue;
			}
			
			if (status2 == "none") {
				timer = 3000; // 3 min
			} else if (status2 == status1) {
				timer = 1000; // 1 min
			} else if (status2 != status1) {
				timer = 10;  // 10 second
			}
			status1 = status2;
			
			// check điều kiện chuyển sang mode đăng ký tự động
			// và điều kiện dừng mode nhận dạng
		}

  }		


















