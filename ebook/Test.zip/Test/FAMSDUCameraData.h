/* Copyright© 2018 FUJITSU LIMITED All Rights Reserved. */
/*!
 * @file        FAMSDUCameraData.h
 * @brief       request camera data defination file
 * @author      ThangLQ
 * @date        2020/01/20
 */

#ifndef FAMS_DATA_UTIL_REQUEST_CAMERA_DATA_H_
#define FAMS_DATA_UTIL_REQUEST_CAMERA_DATA_H_

#include <vector>
#include <string>
#include "FAMSCommon.h"

namespace famsdatautil {
    /*!
     * @class FAMSDUCameraData
     * @brief The class support methods relating camera
     */
    class FAMSDUCameraData {
    public:
        /*!
         * @brief Constructor.
         * @param None.
         * @return None.
         */
        FAMSDUCameraData(void) :
            cameraId {famscommon::JSON_DOUBLE_MISSING_VALUE} {
        }

        /*!
         * @brief getter for id
         * @param None.
         * @return id.
         */
        inline long long getCameraId(void) const {
            return cameraId;
        }

        /*!
         * @brief setter for id
         * @param [in] camera id.
         * @return None.
         */
        inline void setCameraId(long long _cameraId) {
            cameraId = _cameraId;
        }

        inline std::string getTenantCode(void) const {
            return tenantCode;
        }

        inline void setTenantCode(std::string _tenantCode) {
            tenantCode = _tenantCode;
        }
        
        inline std::string getName(void) const {
            return name;
        }

        inline void setName(std::string _name) {
            name = _name;
        }

        inline std::string getDefinedName(void) const {
            return definedName;
        }

        inline void setDefinedName(std::string _definedName) {
            definedName = _definedName;
        }

        inline std::string getHost(void) const {
            return host;
        }

        inline void setHost(std::string _host) {
            host = _host;
        }

        inline std::string getPort(void) const {
            return port;
        }

        inline void setPort(std::string _port) {
            port = _port;
        }
    private:
        //! id
        long long cameraId;
        std::string tenantCode;
        std::string name;
        std::string definedName;
        std::string host;
        std::string port;
    };
}

#endif /* FAMS_DATA_UTIL_REQUEST_CAMERA_DATA_H_ */
