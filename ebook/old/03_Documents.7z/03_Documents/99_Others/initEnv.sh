# It's required for initialized mapdb user before operating
sudo adduser mapdb
sudo passwd mapdb
# Add mapdb to wheel to have privilege to using root
sudo usermod -aG wheel mapdb
# Install necessary libs
cd /home/mapdb/source/fams/rpmbuild/RPMS/x86_64/environment
sudo yum -y install *.rpm
sudo yum -y install devel/*.rpm
sudo yum groupinstall -y 'Development Tools'
sudo yum install -y rpm-build postgresql-server postgresql-contrib postgresql-devel

sudo mkdir /var/lock/mapdb
sudo mkdir /var/run/mapdb
sudo chown mapdb:mapdb /var/lock/mapdb
sudo chown mapdb:mapdb /var/run/mapdb

# Build and deploy
cd /home/mapdb/source/fams/rpmbuild
./build_rpm.sh all delete

sudo postgresql-setup initdb
sudo systemctl start postgresql
sudo systemctl enable postgresql
sudo -i -u postgres
#psql
#postgres=# create user mapdb with encrypted password 'mapdb';
#postgres=# alter user mapdb createdb;
psql -U mapdb -d postgres
#postgres=# create database fams_db;
#postgres=# grant all privileges on database fams_db to mapdb;
#postgres=# GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO mapdb;
#postgres=# GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO mapdb;
#postgres=# \q
exit
psql -U mapdb -d fams_db -a -f /home/mapdb/source/fams_db.sql
#exit
sudo vi /var/lib/pgsql/data/postgresql.conf
# set max_connections to 1500
sudo systemctl restart postgresql

# Install & Remove mdb packages
cd /home/mapdb/source/fams/rpmbuild/RPMS/x86_64/
sudo yum -y remove mdb-*
sudo yum -y install mdb-*
cd /opt/FJSVmapdb
./script/mdbdbgloginit

# Start
./bin/mdbdatamanagementadm start

# Incase cann't access server:
# systemctl stop firewalld

# 192.168.53.5:8081/api/v1/sensor
# {"SensorID":"12345"}
# [{"key":"Content-Type","value":"application/json","description":""}]

# 192.168.53.5:8080/api/v1/application/search-sensor
# {"SensorID":12345}
# [{"key":"Content-Type","value":"application/json","description":""}]


# View queue: cat /dev/mqueue/DataReception_EventProcessing
# ipcs -q
# ipcs
# INSERT INTO user_informations(username,password,mail,full_name) VALUES('famsadmin', 'ZmFtc2FkbWlu', 'admin@fams.com', 'Administrator');
# INSERT INTO user_informations(username,password,mail,full_name) VALUES('famsadmin2', 'ZmFtc2FkbWluMg==', 'admin2@fams.com', 'Administrator2');
